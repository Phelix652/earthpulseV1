import { response, errorResponse, getJson, finiteNumber, boundedCoord } from './_lib.mjs';

export const config = { path: '/api/location' };

export default async (request) => {
  const url = new URL(request.url);
  const lat = boundedCoord(url.searchParams.get('lat'), -90, 90);
  const lon = boundedCoord(url.searchParams.get('lon'), -180, 180);
  if (lat === null || lon === null) return errorResponse('Valid latitude and longitude are required.', 400);

  const weatherUrl = new URL('https://api.open-meteo.com/v1/forecast');
  weatherUrl.searchParams.set('latitude', lat);
  weatherUrl.searchParams.set('longitude', lon);
  weatherUrl.searchParams.set('current', [
    'temperature_2m','relative_humidity_2m','apparent_temperature','precipitation','rain','weather_code','cloud_cover','pressure_msl','wind_speed_10m','wind_gusts_10m','wind_direction_10m'
  ].join(','));
  weatherUrl.searchParams.set('hourly', 'precipitation_probability,rain,weather_code,wind_speed_10m,wind_gusts_10m');
  weatherUrl.searchParams.set('daily', 'weather_code,temperature_2m_max,temperature_2m_min,precipitation_sum,wind_gusts_10m_max');
  weatherUrl.searchParams.set('forecast_days', '3');
  weatherUrl.searchParams.set('timezone', 'auto');

  const floodUrl = new URL('https://flood-api.open-meteo.com/v1/flood');
  floodUrl.searchParams.set('latitude', lat);
  floodUrl.searchParams.set('longitude', lon);
  floodUrl.searchParams.set('daily', 'river_discharge,river_discharge_mean,river_discharge_max,river_discharge_min');
  floodUrl.searchParams.set('forecast_days', '7');
  floodUrl.searchParams.set('timezone', 'auto');

  const marineUrl = new URL('https://marine-api.open-meteo.com/v1/marine');
  marineUrl.searchParams.set('latitude', lat);
  marineUrl.searchParams.set('longitude', lon);
  marineUrl.searchParams.set('current', 'sea_level_height_msl,ocean_current_velocity,ocean_current_direction,wave_height,wave_direction,wind_wave_height,swell_wave_height');
  marineUrl.searchParams.set('timezone', 'auto');
  marineUrl.searchParams.set('forecast_days', '2');

  try {
    const [weather, flood, marine] = await Promise.all([
      getJson(weatherUrl.toString(), { timeoutMs: 12000 }),
      getJson(floodUrl.toString(), { timeoutMs: 12000 }),
      getJson(marineUrl.toString(), { timeoutMs: 12000 })
    ]);
    return response({
      location: { latitude: lat, longitude: lon, timezone: weather.timezone || null, name: weather.timezone || null },
      weather,
      flood,
      marine,
      generated: new Date().toISOString()
    }, 200, 120);
  } catch (err) {
    return errorResponse(`Location data unavailable: ${err.message}`);
  }
};
