import { response } from './_lib.mjs';

export const config = { path: '/api/health' };

export default async () => response({
  ok: true,
  service: 'EarthPulse',
  version: '1.0.0',
  now: new Date().toISOString()
}, 200, 30);
