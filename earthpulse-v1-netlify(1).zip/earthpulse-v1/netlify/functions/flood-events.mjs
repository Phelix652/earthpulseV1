import { response, errorResponse, getJson, finiteNumber } from './_lib.mjs';

export const config = { path: '/api/flood-events' };

function pick(obj, keys) {
  for (const key of keys) if (obj?.[key] !== undefined && obj?.[key] !== null) return obj[key];
  return null;
}

function findArray(data) {
  if (Array.isArray(data)) return data;
  for (const key of ['features','events','data','result','items','eventlist']) {
    if (Array.isArray(data?.[key])) return data[key];
  }
  return [];
}

function normalize(item) {
  const p = item?.properties || item || {};
  const g = item?.geometry;
  let lon = finiteNumber(g?.coordinates?.[0]);
  let lat = finiteNumber(g?.coordinates?.[1]);
  if (lat === null) lat = finiteNumber(p.lat ?? p.latitude ?? p.Latitude);
  if (lon === null) lon = finiteNumber(p.lon ?? p.lng ?? p.longitude ?? p.Longitude);
  const alert = String(p.alertlevel ?? p.alertLevel ?? p.alert ?? p.AlertLevel ?? p.level ?? 'green').toLowerCase();
  return {
    id: String(p.eventid ?? p.eventId ?? p.id ?? item?.id ?? ''),
    name: pick(p, ['eventname','eventName','name','title','description']) || 'Flood event',
    country: pick(p, ['country','countryname','countryName']) || '',
    alertlevel: ['red','orange','green'].includes(alert) ? alert : 'green',
    date: pick(p, ['todate','toDate','date','lastupdate','lastUpdate','fromdate']) || '',
    lat,
    lon,
    url: pick(p, ['url','link','eventurl','eventUrl']) || null
  };
}

export default async (request) => {
  const url = new URL(request.url);
  const days = Math.min(Math.max(Number(url.searchParams.get('days') || 7), 1), 30);
  const end = new Date();
  const start = new Date(end.getTime() - days * 86400000);
  const api = new URL('https://www.gdacs.org/gdacsapi/api/Events/geteventlist/SEARCH');
  api.searchParams.set('eventlist', 'FL');
  api.searchParams.set('fromdate', start.toISOString().slice(0,10));
  api.searchParams.set('todate', end.toISOString().slice(0,10));
  api.searchParams.set('alertlevel', 'green;orange;red');
  try {
    const raw = await getJson(api.toString(), { timeoutMs: 15000 });
    const events = findArray(raw).map(normalize).filter(x => x.id || x.name);
    return response({ source: 'GDACS', generated: new Date().toISOString(), count: events.length, events }, 200, 300);
  } catch (err) {
    return errorResponse(`GDACS flood feed unavailable: ${err.message}`);
  }
};
