import { response, errorResponse, getJson, finiteNumber } from './_lib.mjs';

export const config = { path: '/api/geocode' };

export default async (request) => {
  const url = new URL(request.url);
  const q = (url.searchParams.get('q') || '').trim();
  if (q.length < 2 || q.length > 100) return errorResponse('Search query must be 2–100 characters.', 400);
  const api = new URL('https://geocoding-api.open-meteo.com/v1/search');
  api.searchParams.set('name', q);
  api.searchParams.set('count', '8');
  api.searchParams.set('language', 'en');
  api.searchParams.set('format', 'json');
  try {
    const raw = await getJson(api.toString(), { timeoutMs: 10000 });
    const results = (raw.results || []).map(x => ({
      name: x.name,
      display_name: [x.name,x.admin1,x.country].filter(Boolean).join(', '),
      admin1: x.admin1 || '',
      country: x.country || '',
      latitude: finiteNumber(x.latitude),
      longitude: finiteNumber(x.longitude),
      timezone: x.timezone || null
    })).filter(x => Number.isFinite(x.latitude) && Number.isFinite(x.longitude));
    return response({ source: 'Open-Meteo Geocoding', results }, 200, 600);
  } catch (err) {
    return errorResponse(`Geocoding unavailable: ${err.message}`);
  }
};
