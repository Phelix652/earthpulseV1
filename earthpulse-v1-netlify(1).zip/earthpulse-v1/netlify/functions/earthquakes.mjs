import { response, errorResponse, getJson, finiteNumber } from './_lib.mjs';

export const config = { path: '/api/earthquakes' };

export default async (request) => {
  if (request.method === 'OPTIONS') return response({ ok: true }, 200, 0);
  const url = new URL(request.url);
  const hours = Math.min(Math.max(Number(url.searchParams.get('hours') || 24), 1), 168);
  const minmag = Math.min(Math.max(Number(url.searchParams.get('minmag') || 2.5), -1), 9.9);
  const end = new Date();
  const start = new Date(end.getTime() - hours * 3600 * 1000);
  const api = new URL('https://earthquake.usgs.gov/fdsnws/event/1/query');
  api.searchParams.set('format', 'geojson');
  api.searchParams.set('starttime', start.toISOString());
  api.searchParams.set('endtime', end.toISOString());
  api.searchParams.set('minmagnitude', String(minmag));
  api.searchParams.set('orderby', 'time');
  api.searchParams.set('limit', '20000');
  try {
    const data = await getJson(api.toString(), { timeoutMs: 15000 });
    const events = (data.features || []).map(f => {
      const p = f.properties || {};
      const g = f.geometry?.coordinates || [];
      return {
        id: f.id,
        time: p.time,
        updated: p.updated,
        mag: finiteNumber(p.mag),
        place: p.place || p.title || 'Earthquake',
        depth_km: finiteNumber(g[2]),
        lat: finiteNumber(g[1]),
        lon: finiteNumber(g[0]),
        tsunami: p.tsunami === 1,
        felt: finiteNumber(p.felt),
        significance: finiteNumber(p.sig),
        url: p.url || null,
        status: p.status || null,
        magType: p.magType || null
      };
    }).filter(x => Number.isFinite(x.lat) && Number.isFinite(x.lon) && Number.isFinite(x.mag));
    return response({ source: 'USGS Earthquake Catalog', generated: data.metadata?.generated || Date.now(), count: events.length, events }, 200, 60);
  } catch (err) {
    return errorResponse(`USGS earthquake feed unavailable: ${err.message}`);
  }
};
