import { response, errorResponse, getJson, finiteNumber } from './_lib.mjs';

export const config = { path: '/api/global-weather' };

function buildGrid(step) {
  const points = [];
  for (let lat = -75; lat <= 75; lat += step) {
    for (let lon = -180; lon < 180; lon += step) points.push([lat, lon]);
  }
  return points;
}

function batch(arr, size) {
  const out=[];
  for (let i=0;i<arr.length;i+=size) out.push(arr.slice(i,i+size));
  return out;
}

export default async (request) => {
  const url = new URL(request.url);
  const stepIn = Number(url.searchParams.get('step') || 15);
  const step = [10,15,20].includes(stepIn) ? stepIn : 15;
  const coords = buildGrid(step);
  try {
    const all = [];
    for (const group of batch(coords, 100)) {
      const api = new URL('https://api.open-meteo.com/v1/forecast');
      api.searchParams.set('latitude', group.map(x => x[0]).join(','));
      api.searchParams.set('longitude', group.map(x => x[1]).join(','));
      api.searchParams.set('current', 'temperature_2m,precipitation,rain,weather_code,wind_speed_10m,wind_gusts_10m,wind_direction_10m');
      api.searchParams.set('forecast_days', '1');
      api.searchParams.set('timezone', 'GMT');
      const raw = await getJson(api.toString(), { timeoutMs: 15000 });
      const rows = Array.isArray(raw) ? raw : [raw];
      rows.forEach((x, idx) => {
        const c=x.current||{};
        all.push({
          lat: finiteNumber(x.latitude ?? group[idx]?.[0]), lon: finiteNumber(x.longitude ?? group[idx]?.[1]),
          temperature: finiteNumber(c.temperature_2m), rain: finiteNumber(c.rain), precipitation: finiteNumber(c.precipitation),
          wind: finiteNumber(c.wind_speed_10m), gust: finiteNumber(c.wind_gusts_10m), direction: finiteNumber(c.wind_direction_10m),
          weather_code: finiteNumber(c.weather_code), time: c.time || null
        });
      });
    }
    return response({ source: 'Open-Meteo global weather model grid', step_degrees: step, count: all.length, generated: new Date().toISOString(), points: all }, 200, 600);
  } catch (err) {
    return errorResponse(`Global weather grid unavailable: ${err.message}`);
  }
};
